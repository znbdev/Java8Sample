package com.example;

public class MyTest {
    public static void test() {
        System.out.println("Hello, world!");
    }
}
